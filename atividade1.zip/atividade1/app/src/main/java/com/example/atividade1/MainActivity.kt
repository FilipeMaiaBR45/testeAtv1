package com.example.atividade1

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val activityForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            when(it.resultCode){
                RESULT_OK->{
                    Toast.makeText(this, "AH EH", Toast.LENGTH_SHORT).show()
                }
                RESULT_CANCELED->{
                    Toast.makeText(this, "CANCELOU", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val botaoInvoca: Button = findViewById(R.id.botaoInvoca)
       botaoInvoca.setOnClickListener {
           var i = Intent(this, AlterarDados::class.java)
           var params = Bundle()
           params.putString("NOME", "FILIPE")
           i.putExtras(params)
           //startActivityForResult(i, 99)



        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            99->{
                when(resultCode){
                    Activity.RESULT_OK->{
                        val param = data?.extras
                        val texto = param?.getString("DADOS")
                        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show()
                    }
                    Activity.RESULT_CANCELED->{
                        Toast.makeText(this, "cancelou", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }


}