package com.example.atividade1

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class AlterarDados : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alterar_dados)

        val params = intent.extras
        val texto = params?.getString("NOME", "Nome n enviado")

        val textoRecebido: TextView = findViewById(R.id.textoRecebido)
        textoRecebido.text = texto
    }

    fun doFechar(v:View){
        val intent = Intent()
        intent.putExtra("DADOS", "DEU CERTO")
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}